
void Init_RTI(void);
void SendsChr(char, int);
void SendInit(void);
void SpiStop(void);
